const express = require('express');
const app = express();

app.use(express.json());

// Normal route for testing success
app.get('/success', (req, res) => {
    res.json({ success: true, message: "Everything is working fine!" });
});

// Route that manually triggers an error
app.get('/error', (req, res) => {
    const err = new Error("This is a forced test error");
    err.status = 500;
    throw err; 
});

// Route for testing validation-style errors
app.get('/bad-request', (req, res) => {
    const err = new Error("Invalid input provided");
    err.status = 400;
    throw err;
});

// Fallback for 404 - Route not found
app.use((req, res, next) => {
    const err = new Error("Route not found");
    err.status = 404;
    next(err);
});

// Centralized Error Middleware (Must have 4 arguments)
app.use((err, req, res, next) => {
    const statusCode = err.status || 500;
    
    // Standardized JSON response
    res.status(statusCode).json({
        success: false,
        status: statusCode,
        message: err.message || "Internal Server Error"
    });
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Error Demo server running on port ${PORT}`);
});