const express = require('express');
const app = express();
const PORT = 3000;

// Logger middleware - runs for every single request
app.use((req, res, next) => {
    console.log(`${req.method} request made to: ${req.url}`);
    next(); // Don't forget this or the request will hang
});

// Basic Text Response
app.get('/', (req, res) => {
    res.send("Welcome to Route Handling!");
});

// HTML Response
app.get('/about', (req, res) => {
    res.send("<h1>About Us</h1><p>This is a simple HTML response.</p>");
});

// Dynamic Routing - captures the ID from the URL
app.get('/products/:id', (req, res) => {
    const productId = req.params.id;
    res.send(`Viewing Product ID: ${productId}`);
});

// Query Strings - reads data after the '?' in the URL
// Example: /search?q=phone
app.get('/search', (req, res) => {
    const query = req.query.q;
    res.json({
        message: "Search Results",
        searchingFor: query || "Nothing specified"
    });
});

// 404 Catch-all - must be at the very bottom
app.use((req, res) => {
    res.status(404).send("Page Not Found");
});

app.listen(PORT, () => {
    console.log(`Server is running at http://localhost:${PORT}`);
});