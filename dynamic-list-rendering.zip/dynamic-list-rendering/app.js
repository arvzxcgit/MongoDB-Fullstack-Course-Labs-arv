import React, { useState } from "react";

function App() {
  // Step 2: Initial Data Structure
  const [items, setItems] = useState([
    "Learn React",
    "Practice JavaScript",
    "Build Projects"
  ]);

  const [inputValue, setInputValue] = useState("");

  // Step 4.1: Add Item
  const addItem = () => {
    const trimmedValue = inputValue.trim();

    // Step 5.2: Validation
    if (!trimmedValue) return;

    setItems([...items, trimmedValue]);
    setInputValue("");
  };

  // Step 4.2: Remove Item
  const removeItem = (indexToRemove) => {
    const updatedItems = items.filter((_, index) => index !== indexToRemove);
    setItems(updatedItems);
  };

  return (
    <div style={{ padding: "20px", fontFamily: "Arial" }}>
      <h2>Dynamic List Rendering</h2>

      {/* Input Section */}
      <input
        type="text"
        placeholder="Enter new item"
        value={inputValue}
        onChange={(e) => setInputValue(e.target.value)}
      />
      <button onClick={addItem}>Add</button>

      {/* Step 5.1: Empty List Handling */}
      {items.length === 0 ? (
        <p>No items available.</p>
      ) : (
        <ul>
          {/* Step 3: map() Rendering */}
          {items.map((item, index) => (
            <li key={index}>
              {item}{" "}
              <button onClick={() => removeItem(index)}>Remove</button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default App;